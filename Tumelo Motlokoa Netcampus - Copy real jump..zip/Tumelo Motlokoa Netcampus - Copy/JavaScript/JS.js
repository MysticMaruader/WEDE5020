document.addEventListener("DOMContentLoaded", function () {
    // 1. Live Course Filter Search Bar
    const searchInput = document.getElementById("courseSearch");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            const filter = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".course-card");

            cards.forEach(card => {
                const title = card.querySelector("h2").textContent.toLowerCase();
                const desc = card.querySelector("p").textContent.toLowerCase();
                if (title.includes(filter) || desc.includes(filter)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    // 2. Form Validation Feedback
    const contactForm = document.querySelector("form");
    const feedbackBox = document.getElementById("formFeedback");

    if (contactForm) {
        contactForm.addEventListener("submit", function (e) {
            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const message = document.getElementById("message").value.trim();

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const phoneRegex = /^[0-9+\s()-]{10,15}$/;

            if (name === "" || email === "" || message === "") {
                e.preventDefault();
                showFeedback("Please fill in all required fields before submitting.", "error");
                return;
            }

            if (!emailRegex.test(email)) {
                e.preventDefault();
                showFeedback("Please enter a valid email address.", "error");
                return;
            }

            if (phone !== "" && !phoneRegex.test(phone)) {
                e.preventDefault();
                showFeedback("Please enter a valid phone number format.", "error");
                return;
            }
        });
    }

    function showFeedback(message, type) {
        if (!feedbackBox) return;
        feedbackBox.style.display = "block";
        feedbackBox.textContent = message;
        feedbackBox.style.backgroundColor = type === "error" ? "#fee2e2" : "#d1fae5";
        feedbackBox.style.color = type === "error" ? "#991b1b" : "#065f46";
    }
});

document.addEventListener("DOMContentLoaded", function () {
    // 1. Live Course Filter Search
    const searchInput = document.getElementById("courseSearch");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            const filter = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".course-card");

            cards.forEach(card => {
                const title = card.querySelector("h2").textContent.toLowerCase();
                const desc = card.querySelector("p").textContent.toLowerCase();
                if (title.includes(filter) || desc.includes(filter)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    // 2. Rotating Image-Swapping Animation for About Page
    const sliderImages = document.querySelectorAll(".slider-image");
    if (sliderImages.length > 0) {
        let currentIndex = 0;
        setInterval(() => {
            sliderImages[currentIndex].classList.remove("active");
            currentIndex = (currentIndex + 1) % sliderImages.length;
            sliderImages[currentIndex].classList.add("active");
        }, 4000); // Swaps image every 4 seconds smoothly
    }
});