document.addEventListener("DOMContentLoaded", function () {
   
    const searchInput = document.getElementById("courseSearch");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            const filter = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".course-card");

            cards.forEach(card => {
                const title = card.querySelector("h2").textContent.toLowerCase();
                const desc = card.querySelector("p").textContent.toLowerCase();
                if (title.includes(filter) || desc.includes(filter)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

     
    const contactForm = document.querySelector("form");
    const feedbackBox = document.getElementById("formFeedback");

    if (contactForm) {
        contactForm.addEventListener("submit", function (e) {
            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const message = document.getElementById("message").value.trim();

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const phoneRegex = /^[0-9+\s()-]{10,15}$/;

            if (name === "" || email === "" || message === "") {
                e.preventDefault();
                showFeedback("Please fill in all required fields before submitting.", "error");
                return;
            }

            if (!emailRegex.test(email)) {
                e.preventDefault();
                showFeedback("Please enter a valid email address.", "error");
                return;
            }

            if (phone !== "" && !phoneRegex.test(phone)) {
                e.preventDefault();
                showFeedback("Please enter a valid phone number format.", "error");
                return;
            }
        });
    }

    function showFeedback(message, type) {
        if (!feedbackBox) return;
        feedbackBox.style.display = "block";
        feedbackBox.textContent = message;
        feedbackBox.style.backgroundColor = type === "error" ? "#fee2e2" : "#d1fae5";
        feedbackBox.style.color = type === "error" ? "#991b1b" : "#065f46";
    }
});

document.addEventListener("DOMContentLoaded", function () {
   
    const searchInput = document.getElementById("courseSearch");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            const filter = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".course-card");

            cards.forEach(card => {
                const title = card.querySelector("h2").textContent.toLowerCase();
                const desc = card.querySelector("p").textContent.toLowerCase();
                if (title.includes(filter) || desc.includes(filter)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    
    const sliderImages = document.querySelectorAll(".slider-image");
    if (sliderImages.length > 0) {
        let currentIndex = 0;
        setInterval(() => {
            sliderImages[currentIndex].classList.remove("active");
            currentIndex = (currentIndex + 1) % sliderImages.length;
            sliderImages[currentIndex].classList.add("active");
        }, 4000); 
    }
});
document.addEventListener("DOMContentLoaded", () => {
    
    const lightbox = document.createElement("div");
    lightbox.id = "lightbox";
    lightbox.style.cssText = `
        display: none;
        position: fixed;
        z-index: 1000;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background-color: rgba(0, 0, 0, 0.85);
        justify-content: center;
        align-items: center;
        cursor: pointer;
    `;

    const lightboxImg = document.createElement("img");
    lightboxImg.style.cssText = `
        max-width: 90%;
        max-height: 80%;
        border-radius: 8px;
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
    `;

    lightbox.appendChild(lightboxImg);
    document.body.appendChild(lightbox);


    const images = document.querySelectorAll("main img");
    images.forEach(img => {
        img.style.cursor = "pointer";
        img.addEventListener("click", () => {
            lightboxImg.src = img.src;
            lightbox.style.display = "flex";
        });
    });

    
    lightbox.addEventListener("click", () => {
        lightbox.style.display = "none";
    });
});

document.addEventListener("DOMContentLoaded", () => {
    // 1. Create Lightbox Overlay Element dynamically
    const lightbox = document.createElement("div");
    lightbox.id = "lightbox-modal";
    lightbox.style.cssText = `
        display: none;
        position: fixed;
        z-index: 9999;
        top: 0; 
        left: 0;
        width: 100vw; 
        height: 100vh;
        background-color: rgba(0, 0, 0, 0.9);
        justify-content: center;
        align-items: center;
        cursor: pointer;
    `;

    const lightboxImg = document.createElement("img");
    lightboxImg.style.cssText = `
        max-width: 90%;
        max-height: 85%;
        border-radius: 8px;
        box-shadow: 0 5px 25px rgba(0, 0, 0, 0.5);
        object-fit: contain;
    `;

    lightbox.appendChild(lightboxImg);
    document.body.appendChild(lightbox);

    // 2. Use Event Delegation on the document body to catch image clicks
    document.body.addEventListener("click", (e) => {
        // Check if the clicked element is an image inside main content or profile sections
        if (e.target.tagName === "IMG" && !e.target.closest("#lightbox-modal")) {
            lightboxImg.src = e.target.src;
            lightbox.style.display = "flex";
        }
    });

    // 3. Close Lightbox when clicking anywhere on the overlay
    lightbox.addEventListener("click", () => {
        lightbox.style.display = "none";
    });
});
document.addEventListener("DOMContentLoaded", () => {
    // 1. Create the lightbox container and image element dynamically
    const lightbox = document.createElement("div");
    lightbox.id = "image-lightbox";
    lightbox.style.cssText = `
        display: none;
        position: fixed;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(0, 0, 0, 0.85);
        justify-content: center;
        align-items: center;
        cursor: pointer;
    `;

    const lightboxImg = document.createElement("img");
    lightboxImg.style.cssText = `
        max-width: 90%;
        max-height: 85%;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.5);
        object-fit: contain;
    `;

    lightbox.appendChild(lightboxImg);
    document.body.appendChild(lightbox);

    // 2. Select all images inside your main content or profile sections
    const galleryImages = document.querySelectorAll("main img");

    galleryImages.forEach(img => {
        // Add a pointer cursor so users know it's clickable
        img.style.cursor = "pointer";

        // Click event to open image in lightbox
        img.addEventListener("click", () => {
            lightboxImg.src = img.src;
            lightbox.style.display = "flex";
        });
    });

    // 3. Close the lightbox when clicking anywhere on the overlay/image
    lightbox.addEventListener("click", () => {
        lightbox.style.display = "none";
    });
});
(function() {
    // Run immediately and also on load to ensure it catches everything
    function initLightbox() {
        // Check if lightbox already exists to prevent duplicates
        if (document.getElementById("image-lightbox")) return;

        const lightbox = document.createElement("div");
        lightbox.id = "image-lightbox";
        lightbox.style.cssText = `
            display: none;
            position: fixed;
            z-index: 99999;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.9);
            justify-content: center;
            align-items: center;
            cursor: pointer;
        `;

        const lightboxImg = document.createElement("img");
        lightboxImg.style.cssText = `
            max-width: 90%;
            max-height: 85%;
            border-radius: 8px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.7);
            object-fit: contain;
        `;

        lightbox.appendChild(lightboxImg);
        document.body.appendChild(lightbox);

        // Target every image on the page
        const images = document.querySelectorAll("img");

        images.forEach(img => {
            // Skip the lightbox image itself if it gets queried
            if (img === lightboxImg) return;

            img.style.cursor = "pointer";

            img.addEventListener("click", (e) => {
                // Prevent default link behavior if the image is wrapped in an <a> tag
                e.preventDefault();
                e.stopPropagation();

                lightboxImg.src = img.src;
                lightbox.style.display = "flex";
            });
        });

        // Close when clicking anywhere on the dark overlay
        lightbox.addEventListener("click", () => {
            lightbox.style.display = "none";
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initLightbox);
    } else {
        initLightbox();
    }
})();

document.addEventListener("DOMContentLoaded", () => {
    // 1. Create the lightbox modal overlay
    const lightbox = document.createElement("div");
    lightbox.id = "image-lightbox";
    lightbox.style.cssText = `
        display: none;
        position: fixed;
        z-index: 999999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(0, 0, 0, 0.9);
        justify-content: center;
        align-items: center;
        cursor: zoom-out;
    `;

    const lightboxImg = document.createElement("img");
    lightboxImg.style.cssText = `
        max-width: 90%;
        max-height: 85%;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.8);
        object-fit: contain;
    `;

    lightbox.appendChild(lightboxImg);
    document.body.appendChild(lightbox);

    // 2. Target every image on the page
    const images = document.querySelectorAll("img");

    images.forEach(img => {
        // Skip if it's somehow part of the lightbox itself
        if (img === lightboxImg) return;

        // Make cursor show it's clickable
        img.style.cursor = "zoom-in";

        // Open lightbox on click
        img.addEventListener("click", (e) => {
            e.stopPropagation();
            lightboxImg.src = img.src;
            lightbox.style.display = "flex";
        });
    });

    // 3. Close lightbox when clicking anywhere on the dark background
    lightbox.addEventListener("click", () => {
        lightbox.style.display = "none";
    });
});